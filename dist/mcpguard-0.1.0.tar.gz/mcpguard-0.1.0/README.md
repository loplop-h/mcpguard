<p align="center">
<pre>
                                                  _
  _ __ ___   ___ _ __   __ _ _   _  __ _ _ __ __| |
 | '_ ` _ \ / __| '_ \ / _` | | | |/ _` | '__/ _` |
 | | | | | | (__| |_) | (_| | |_| | (_| | | | (_| |
 |_| |_| |_|\___| .__/ \__, |\__,_|\__,_|_|  \__,_|
                 |_|    |___/
</pre>
</p>

<p align="center"><strong>Find security vulnerabilities in your MCP server configs before attackers do.</strong></p>
<p align="center">Maps every finding to the OWASP MCP Top 10. Zero config. Runs locally.</p>

<p align="center">
  <a href="https://pypi.org/project/mcpguard/"><img src="https://img.shields.io/pypi/v/mcpguard?style=flat-square" alt="PyPI"></a>
  <a href="https://pypi.org/project/mcpguard/"><img src="https://img.shields.io/pypi/pyversions/mcpguard?style=flat-square" alt="Python"></a>
  <a href="LICENSE"><img src="https://img.shields.io/badge/license-MIT-blue?style=flat-square" alt="License"></a>
  <a href="https://github.com/loplop-h/mcpguard/stargazers"><img src="https://img.shields.io/github/stars/loplop-h/mcpguard?style=flat-square" alt="Stars"></a>
  <a href="https://owasp.org/www-project-mcp-top-10/"><img src="https://img.shields.io/badge/OWASP-MCP%20Top%2010-orange?style=flat-square" alt="OWASP"></a>
</p>

---

<p align="center">
  <img src="https://raw.githubusercontent.com/loplop-h/mcpguard/master/docs/scan-screenshot.png" alt="mcpguard scan output" width="650">
</p>

## Quick Start

```bash
pip install mcpguard
mcpguard scan
```

That's it. mcpguard auto-detects MCP configs from Claude Desktop, Claude Code, Cursor, VS Code, and Windsurf. No API keys, no accounts, everything runs locally.

## What It Scans For

mcpguard checks your MCP server configurations against the [OWASP MCP Top 10](https://owasp.org/www-project-mcp-top-10/):

| | Risk | What mcpguard detects |
|---|------|----------------------|
| Y | **MCP01** Token & Secret Exposure | Hardcoded API keys (AWS, OpenAI, GitHub, Anthropic, Stripe), high-entropy secrets, JWT tokens |
| Y | **MCP02** Privilege Escalation | Wildcard `alwaysAllow`, overpermissioned tool scopes |
| Y | **MCP04** Supply Chain Attacks | Unpinned `@latest` versions, missing version locks |
| Y | **MCP05** Command Injection | Shell metacharacters in args, dangerous commands |
| Y | **MCP07** Missing Authentication | HTTP servers without auth headers, plaintext HTTP transport |
| Y | **MCP09** Shadow Servers | Localhost/dev URLs in configs, unregistered servers |
| - | MCP03 Tool Poisoning | Planned (requires server connection) |
| - | MCP06 Intent Subversion | Planned (requires runtime analysis) |
| - | MCP08 No Audit Logging | Planned |
| - | MCP10 Context Over-Sharing | Planned |

## Features

- **Zero config** -- auto-discovers configs from 5 MCP clients
- **OWASP mapped** -- every finding links to OWASP MCP Top 10
- **16 detection rules** -- secrets, auth, permissions, supply chain, injection, shadow servers
- **Entropy-based secret detection** -- catches secrets that don't match known patterns
- **Auto-fix** -- `mcpguard fix` replaces hardcoded secrets with `${VAR}` references
- **Custom rules** -- add your own YAML detection rules
- **SARIF output** -- integrates with GitHub Security tab
- **GitHub Action** -- drop-in CI/CD security gate
- **Pre-commit hook** -- catch issues before they're committed
- **No network** -- everything runs locally, no API calls

## Usage

```bash
# Scan all auto-detected configs
mcpguard scan

# Scan a specific config file
mcpguard scan --path /path/to/mcp.json

# Auto-fix hardcoded secrets, HTTP URLs, wildcard permissions
mcpguard fix

# Preview fixes without modifying files
mcpguard fix --dry-run

# JSON output for CI/CD
mcpguard scan --format json

# SARIF output for GitHub Security tab
mcpguard scan --format sarif -o results.sarif

# Only show critical and high findings
mcpguard scan --severity high

# Quick pass/fail check (exit code only)
mcpguard check

# Add custom detection rules
mcpguard scan --rules-dir ./my-rules/
```

## Auto-Fix

mcpguard can automatically fix common security issues:

```bash
mcpguard fix
```

What it fixes:
- Replaces hardcoded API keys with `${VAR_NAME}` environment variable references
- Upgrades `http://` URLs to `https://`
- Removes wildcard `alwaysAllow: ["*"]`
- Creates a `.mcpguard-backup` before modifying any file

## Supported Clients

| Client | Config Location |
|--------|----------------|
| Claude Desktop | `~/Library/Application Support/Claude/claude_desktop_config.json` |
| Claude Code | `~/.claude.json`, `.mcp.json` |
| Cursor | `~/.cursor/mcp.json`, `.cursor/mcp.json` |
| VS Code | `~/.config/Code/User/mcp.json`, `.vscode/mcp.json` |
| Windsurf | `~/.codeium/windsurf/mcp_config.json` |

## Custom Rules

mcpguard uses YAML detection rules. Add your own:

```yaml
id: CUSTOM-001
info:
  name: Internal API Key Pattern
  severity: critical
  owasp: MCP01
  description: Detects internal API keys
  remediation: Use vault references
  cwe: CWE-798
detection:
  target: config
  scope: env_values
  match:
    type: regex
    patterns:
      - 'internal_[a-z0-9]{32}'
```

```bash
mcpguard scan --rules-dir ./my-rules/
```

## GitHub Action

```yaml
name: MCP Security Scan
on: [push, pull_request]

jobs:
  mcpguard:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: loplop-h/mcpguard@v1
```

Or manually:

```yaml
      - run: pip install mcpguard
      - run: mcpguard scan --format sarif -o results.sarif
      - uses: github/codeql-action/upload-sarif@v3
        with:
          sarif_file: results.sarif
```

## Pre-commit Hook

```yaml
# .pre-commit-config.yaml
repos:
  - repo: https://github.com/loplop-h/mcpguard
    rev: v0.1.0
    hooks:
      - id: mcpguard
```

## Privacy

- All data stays on your machine
- No external API calls, no telemetry
- Only reads config files, never connects to MCP servers
- Open source, MIT licensed

## Contributing

```bash
git clone https://github.com/loplop-h/mcpguard.git
cd mcpguard
pip install -e ".[dev]"
pytest
```

Add detection rules in `src/mcpguard/rules/` using the YAML schema above.

## License

MIT
